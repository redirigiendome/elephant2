from django.contrib import admin

from zapateria.models import cliente

# Register your models here.
class clienteAdm(admin.ModelAdmin):
    list_display=("nombre", "telefono", "direccion")


admin.site.register(cliente,clienteAdm)
