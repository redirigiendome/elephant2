from django.apps import AppConfig


class zapateriaConfig(AppConfig):
    name = 'zapateria'
