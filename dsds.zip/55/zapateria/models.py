from django.db import models

# Create your models here.

class cliente(models.Model):
    telefono = models.IntegerField()
    nombre=models.CharField(max_length=50)
    direccion=models.CharField(max_length=100)