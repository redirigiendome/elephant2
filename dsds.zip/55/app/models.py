"""
Definition of models.
"""

from django.db import models

# Create your models here.
class cliente(models.Model):
    nombre= models.CharField(max_length=100)
    celular = models.CharField(max_length=50)